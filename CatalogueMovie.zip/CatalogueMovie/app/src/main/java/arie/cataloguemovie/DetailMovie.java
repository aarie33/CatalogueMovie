package arie.cataloguemovie;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class DetailMovie extends AppCompatActivity {
    public static String TAG = DetailMovie.class.getSimpleName();
    private ImageView imgBackdrop, imgPoster, imgShare, imgFavorite;
    private TextView txtTitle, txtRating, txtBahasa, txtReleaseDate,
            txtRuntime, txtOverview, txtTagline, txtTrailer, txtFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        imgBackdrop = findViewById(R.id.img_backdrop_path);
        imgPoster = findViewById(R.id.img_poster_path);
        txtTitle = findViewById(R.id.txt_title);
        txtRating = findViewById(R.id.txt_rate);
        txtBahasa = findViewById(R.id.txt_bahasa);
        txtReleaseDate = findViewById(R.id.txt_release_date);
        txtRuntime = findViewById(R.id.txt_runtime);
        txtOverview = findViewById(R.id.txt_overview);
        txtTagline = findViewById(R.id.txt_tagline);

        setTitle(getIntent().getStringExtra("nama"));
        Log.i("ID Intent", String.valueOf(getIntent().getIntExtra("id",0)));
        txtTitle.setText(getIntent().getStringExtra("nama"));
        AsyncDetailMovie asyncDetailMovie = new AsyncDetailMovie();
        asyncDetailMovie.execute(getIntent().getIntExtra("id",0));
    }

    private class AsyncDetailMovie extends AsyncTask<Integer, Void, JSONObject> {

        @Override
        protected JSONObject doInBackground(Integer... integers) {
            return getDetail(integers[0]);
        }

        @Override
        protected void onPostExecute(JSONObject object) {
            super.onPostExecute(object);
            Log.i("Post Execute" , String.valueOf(object));
            try {
                Log.i("OBJECT", object.getString("overview").toString());
                txtRating.setText(String.valueOf(object.getInt("vote_average")));
                txtReleaseDate.setText(object.getString("release_date").toString());
                txtBahasa.setText(object.getString("original_language").toString());
                txtRuntime.setText(String.valueOf(object.getDouble("runtime")));
                txtOverview.setText(object.getString("overview").toString());
                txtTagline.setText(object.getString("tagline").toString());

                Glide.with(getApplicationContext()).load("https://image.tmdb.org/t/p/w185/" +
                        object.getString("poster_path").toString()).into(imgPoster);
                Glide.with(getApplicationContext()).load("https://image.tmdb.org/t/p/w342/" +
                        object.getString("backdrop_path").toString()).into(imgBackdrop);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private JSONObject getDetail(int movieId){
        SyncHttpClient syncHttpClient = new SyncHttpClient();
        final JSONObject[] jsonObject = {new JSONObject()};
        String url = "https://api.themoviedb.org/3/movie/" + movieId + "?" +
                "api_key="+ BuildConfig.ApiKey+"&language=en-US&query="+movieId;

        syncHttpClient.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                Log.i("Success out try", String.valueOf(responseBody));
                JSONObject object;
                try {
                    String result = new String(responseBody);
                    object = new JSONObject(result);
                } catch (JSONException e) {
                    e.printStackTrace();
                    object = null;
                    Log.e("ERROR CATCH SYNC MOVIE", String.valueOf(e));
                }
                jsonObject[0] = object;

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("ERROR GET SYNC MOVIE", String.valueOf(responseBody));
            }
        });
        return jsonObject[0];
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
            return false;
        }
        return super.onOptionsItemSelected(item);
    }
}
